# Deployd-example
Example of use deployd
My instance of deployd is publishing by special address (view HW doc)
To create you'r own resourses you need to use addresByHomeWork/dashboard
After this you may implement CRUD operation like example.


P.S. Don't remove existent resourse
